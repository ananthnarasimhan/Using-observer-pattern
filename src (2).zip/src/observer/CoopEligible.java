package observer;

/**
 * This class represents the observer for coop eligibility. This observer
 * receives update from the GradeSubject class and decides whether it is
 * possible to go for a coop.
 * 
 * @author ananth
 *
 */
public class CoopEligible extends AbstractGradeObserver {
  @Override
  public boolean isSatisfied() {
    // TODO Auto-generated method stub
    int totalCredits = 0;
    for (GradeRecord rec : records) {
      totalCredits += rec.getCredits();

    }
    return ((totalCredits >= 16) && (super.averageScore()));
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("Coop Eligible observer:");
    if (records.size() <= 0) {
      return String.format(sb.toString());
    }
    sb.append("Courses");
    for (int i = 0; i < records.size(); i++) {
      sb.append(records.get(i).getCourse() + ",");
    }
    return String.format(sb.toString().toString().substring(0, sb.length() - 1));
  }
}
