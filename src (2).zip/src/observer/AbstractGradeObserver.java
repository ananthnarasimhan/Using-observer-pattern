package observer;

import java.util.ArrayList;
import java.util.List;

/**
 * This is a abstract class which implements the grade observer class. It
 * implements all the common methods of observers.
 * 
 * @author ananth
 *
 */
public class AbstractGradeObserver implements GradeObserver {
  protected List<GradeRecord> records;

  /**
   * This constructor initializes the list of records to an array list.
   */
  public AbstractGradeObserver() {
    // TODO Auto-generated method stub
    records = new ArrayList<>();
  }

  private int chkPresent(GradeRecord record) {
    for (GradeRecord rec : records) {
      if (record.getCourse().equals(rec.getCourse())) {
        if (record.getGrade().getGradeValue() > rec.getGrade().getGradeValue()) {
          return records.indexOf(rec);
        } else {
          return -2;
        }
      }
    }
    return -1;
  }

  @Override
  public void update(GradeRecord record) {
    if (record == null) {
      throw new IllegalArgumentException("record can't be null");
    }
    // TODO Auto-generated method stub
    if (chkPresent(record) > -1) {
      records.set(chkPresent(record),
          new GradeRecord(record.getCourse(), record.getGrade(), record.getCredits()));
    } else if (chkPresent(record) == -1) {
      records.add(record);
    }
  }

  @Override
  public boolean isSatisfied() {
    // TODO Auto-generated method stub
    return false;
  }

  protected boolean averageScore() {
    float totalGrades = 0;
    for (GradeRecord rec : records) {
      totalGrades += rec.getGrade().getGradeValue();
    }
    return ((totalGrades / records.size()) > 3.00);
  }

}
