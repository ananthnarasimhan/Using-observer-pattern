package observer;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents the grade subject. It specifically implements
 * GradeSubject.
 * 
 * @author ananth
 *
 */
public class GradeSubjectImpl implements GradeSubject {
  private List<GradeObserver> listOfObservers;

  /**
   * This is the constructor which initializes the list of observers to an array list.
   */
  public GradeSubjectImpl() {
    // TODO Auto-generated constructor stub
    listOfObservers = new ArrayList<GradeObserver>();
  }

  @Override
  public void attach(GradeObserver observer) {
    // TODO Auto-generated method stub
    if (observer == null) {
      throw new IllegalArgumentException("observer can't be null");
    }
    if (listOfObservers.contains(observer)) {
      return;
    }
    listOfObservers.add(observer);
  }

  @Override
  public void detach(GradeObserver observer) {
    // TODO Auto-generated method stub
    if (observer == null) {
      throw new IllegalArgumentException("observer can't be null");
    }
    if (listOfObservers.contains(observer)) {
      listOfObservers.remove(observer);
    } else {
      throw new IllegalStateException("observer not found");
    }
  }

  @Override
  public void notify(GradeRecord record) {
    // TODO Auto-generated method stub

    if (record == null) {
      throw new IllegalArgumentException("record can't be null");
    }
    for (GradeObserver observer : listOfObservers) {
      GradeRecord duplicateRecord = new GradeRecord(record.getCourse(), record.getGrade(),
          record.getCredits());
      observer.update(duplicateRecord);
    }
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("List of observers:");
    if (listOfObservers.size() == 0) {
      return String.format(sb.toString());
    }
    StringBuilder sb1 = new StringBuilder();

    for (int i = 0; i < listOfObservers.size(); i++) {
      sb1.append(listOfObservers.get(i).toString() + ",");
    }

    return String.format(sb + sb1.toString().substring(0, sb1.length() - 1));
  }

}
