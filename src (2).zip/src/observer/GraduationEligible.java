package observer;

/**
 * This class represents the observer for coop eligibility. This observer
 * receives updates from the GradeSubject class and decides whether it is
 * possible for Graduation.
 * 
 * @author ananth
 *
 */
public class GraduationEligible extends AbstractGradeObserver {

  @Override
  public boolean isSatisfied() {
    // TODO Auto-generated method stub

    double totalGradesInCoreSubjects = 0;
    boolean completedCourseFiftyTen = false;
    boolean completedCourseFiveEightHundered = false;
    boolean completedCourseFiftyFiveHundredOrFiftySixHundred = false;
    for (GradeRecord rec : super.records) {
      if (rec.getCourse().equals("CS5010") || rec.getCourse().equals("CS5004")) {
        completedCourseFiftyTen = true;
        totalGradesInCoreSubjects += rec.getGrade().getGradeValue();
      } else if (rec.getCourse().equals("CS5800")) {
        completedCourseFiveEightHundered = true;
        totalGradesInCoreSubjects += rec.getGrade().getGradeValue();
      } else if (rec.getCourse().equals("CS5500") || rec.getCourse().equals("CS5600")) {
        completedCourseFiftyFiveHundredOrFiftySixHundred = true;
        totalGradesInCoreSubjects += rec.getGrade().getGradeValue();
      }
    }
    return (completedCourseFiftyTen && completedCourseFiveEightHundered
        && completedCourseFiftyFiveHundredOrFiftySixHundred
        && ((totalGradesInCoreSubjects / 3) > 3.00));
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("Graduation Eligible observer:");
    if (records.size() <= 0) {
      return String.format(sb.toString());
    }
    sb.append("Courses");
    for (int i = 0; i < records.size(); i++) {
      sb.append(records.get(i).getCourse() + ",");
    }
    return String.format(sb.toString().toString().substring(0, sb.length() - 1));
  }

}
