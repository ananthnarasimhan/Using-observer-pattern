package observer;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * Testing the GradeSubjectImpl class.
 * 
 * @author ananth
 *
 */
public class GradeSubjectImplTest {
  private GradeSubject student;
  private GradeObserver obs;
  private GradeObserver coop1;
  private GradeObserver coop2;
  private GradeObserver goodStanding1;
  private GradeObserver goodStanding2;
  private GradeObserver graduationEligible1;
  private GradeObserver graduationEligible2;

  /**
   * Setting up test cases.
   */
  @Before
  public void setUp() {
    student = new GradeSubjectImpl();
    obs = new MockObserver();
    coop1 = new CoopEligible();
    coop2 = new CoopEligible();
    goodStanding1 = new GoodStanding();
    goodStanding2 = new GoodStanding();
    graduationEligible1 = new GraduationEligible();
    graduationEligible2 = new GraduationEligible();
    student.attach(obs);
  }

  /**
   * Testing attaching null observer.
   */
  @Test(expected = IllegalArgumentException.class)
  public void attachNullObserver() {
    student.attach(null);
  }

  /**
   * Testing detaching null observer.
   */
  @Test(expected = IllegalArgumentException.class)
  public void detachNullObserver() {
    student.detach(null);
  }

  /**
   * Testing notifying for null record.
   */
  @Test(expected = IllegalArgumentException.class)
  public void notifyNullRecord() {
    student.notify(null);
  }

  /**
   * Testing single attaching single observer.
   */
  @Test
  public void testAttach() {
    student.attach(obs);
    assertEquals("List of observers:Mock observer", student.toString());
    student.detach(obs);
    assertEquals("List of observers:", student.toString());
  }

  /**
   * Testing multiple attaching single observer.
   */
  @Test
  public void testMultipleAttachAndDetachofSameTypeAsWellAsDifferentType() {
    student.attach(obs);
    assertEquals("List of observers:Mock observer", student.toString());
    student.attach(coop1);
    assertEquals("List of observers:Mock observer,Coop Eligible observer:", student.toString());
    student.attach(goodStanding1);
    assertEquals("List of observers:Mock observer,Coop Eligible observer:,Good Standing observer:",
        student.toString());
    student.attach(graduationEligible1);
    GradeRecord highMarksSubjectCS5010 = new GradeRecord("CS5010", Grade.A, 4);
    assertEquals("List of observers:Mock observer,Coop Eligible observer:,Good Standing"
        + " observer:,Graduation Eligible observer:", student.toString());

    student.notify(highMarksSubjectCS5010);

    student.attach(coop2);
    assertEquals("List of observers:Mock observer,Coop Eligible observer:"
        + "CoursesCS5010,Good Standing observer:CoursesCS5010,Graduation Eligible"
        + " observer:CoursesCS5010,Coop Eligible observer:", student.toString());
    student.attach(goodStanding2);
    assertEquals("List of observers:Mock observer,Coop Eligible observer:"
        + "CoursesCS5010,Good Standing observer:CoursesCS5010,"
        + "Graduation Eligible observer:CoursesCS5010,Coop Eligible observer:,"
        + "Good Standing observer:", student.toString());
    student.attach(graduationEligible2);
    assertEquals(
        "List of observers:Mock observer,Coop Eligible observer:"
            + "CoursesCS5010,Good Standing observer:CoursesCS5010,"
            + "Graduation Eligible observer:CoursesCS5010,"
            + "Coop Eligible observer:,Good Standing observer:" + ",Graduation Eligible observer:",
        student.toString());

    student.detach(coop2);
    assertEquals("List of observers:Mock observer,Coop Eligible observer:"
        + "CoursesCS5010,Good Standing observer:CoursesCS5010,"
        + "Graduation Eligible observer:CoursesCS5010,Good Standing observer:,"
        + "Graduation Eligible observer:", student.toString());

    student.detach(goodStanding2);
    assertEquals(
        "List of observers:Mock observer,Coop Eligible observer:"
            + "CoursesCS5010,Good Standing observer:CoursesCS5010,"
            + "Graduation Eligible observer:CoursesCS5010," + "Graduation Eligible observer:",
        student.toString());

    student.detach(graduationEligible2);
    assertEquals("List of observers:Mock observer,Coop Eligible observer:"
        + "CoursesCS5010,Good Standing observer:CoursesCS5010,"
        + "Graduation Eligible observer:CoursesCS5010", student.toString());

    student.detach(obs);
    assertEquals("List of observers:Coop Eligible observer:CoursesCS5010,"
        + "Good Standing observer:CoursesCS5010,Graduation Eligible observer:" + "CoursesCS5010",
        student.toString());

    student.detach(coop1);
    assertEquals("List of observers:Good Standing observer:CoursesCS5010,"
        + "Graduation Eligible observer:CoursesCS5010", student.toString());

    student.detach(goodStanding1);
    assertEquals("List of observers:Graduation Eligible observer:CoursesCS5010",
        student.toString());

    student.detach(graduationEligible1);
    assertEquals("List of observers:", student.toString());
  }

  /**
   * Testing to detach from a the grade subject where that observer is not
   * present.
   */
  @Test(expected = IllegalStateException.class)
  public void testDetachFromNobserversPresent() {
    student.detach(coop1);
  }
}
