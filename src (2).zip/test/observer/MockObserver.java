package observer;

/**
 * This is a mock observer which represnts a type of observer. This observer
 * does not contain any implementation but only contains methods to check the
 * GradeSubjectImpl.
 * 
 * @author ananth
 *
 */
public class MockObserver implements GradeObserver {

  @Override
  public void update(GradeRecord record) {
    // TODO Auto-generated method stub

  }

  @Override
  public boolean isSatisfied() {
    // TODO Auto-generated method stub
    return true;
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("Mock observer");

    return String.format(sb.toString());
  }
}
