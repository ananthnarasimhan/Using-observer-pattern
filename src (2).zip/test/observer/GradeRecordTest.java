package observer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * This class represents the testing for the Grade Record subject.
 * 
 * @author ananth
 *
 */
public class GradeRecordTest {
  private GradeRecord coursePdp;

  private GradeRecord courseAlgorithm;
  private GradeRecord coursePdpCopy;

  /**
   * Setting up the test cases.
   */
  @Before
  public void setUp() {
    coursePdp = new GradeRecord("CS5010", Grade.A, 4);

    courseAlgorithm = new GradeRecord("CS5800", Grade.B, 4);
    coursePdpCopy = new GradeRecord("CS5010", Grade.A, 4);

  }

  /**
   * Testing for equals method of grade subjects.
   */
  @Test
  public void testEquals() {
    assertEquals(true, coursePdp.equals(coursePdp));
    assertEquals(true, coursePdp.equals(coursePdpCopy));
    assertEquals(true, coursePdpCopy.equals(coursePdp));
  }

  /**
   * Testing for hashcode.
   */
  @Test
  public void testHashCode() {
    assertEquals(coursePdp.hashCode(), coursePdp.hashCode());
    assertNotEquals(courseAlgorithm.hashCode(), coursePdp.hashCode());
  }

  /**
   * Testing for toString Method.
   */
  @Test
  public void testtoString() {
    assertEquals("GradeRecord[course=CS5010, grade=A, credits=4]", coursePdp.toString());
  }

  /**
   * Test for empty values for course name.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testForNullCourseName() {
    coursePdp = new GradeRecord(null, Grade.A, 4);
  }

  /**
   * Test for empty values for grade.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testForNullGrade() {
    coursePdp = new GradeRecord("CS5010", null, 4);
  }

  /**
   * Test for negative value for credits.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testForNegativeCredits() {
    coursePdp = new GradeRecord(null, Grade.A, -4);
  }
  /*
   * equals hashcode toString Enum all grades check for value empty values null
   * check
   */
}
