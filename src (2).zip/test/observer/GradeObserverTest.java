package observer;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * Testing for various possible test cases for the observers.
 * 
 * @author ananth
 *
 */
public class GradeObserverTest {
  private GradeObserver coopObserver;
  private GradeObserver goodStandingObserver;
  private GradeObserver graduationEligibleObserver;
  private GradeSubject student;
  private GradeRecord coursePdp;
  private GradeRecord courseDbms;
  private GradeRecord courseAlgorithm;
  private GradeRecord course5600;
  private GradeRecord course5500;
  private GradeRecord course5004;
  private GradeRecord course5005;
  private GradeRecord subject5100;

  /**
   * Setting up the test cases.
   */
  @Before
  public void setUp() {
    coopObserver = new CoopEligible();
    goodStandingObserver = new GoodStanding();
    graduationEligibleObserver = new GraduationEligible();
    student = new GradeSubjectImpl();
    coursePdp = new GradeRecord("CS5010", Grade.A, 4);
    courseDbms = new GradeRecord("CS5200", Grade.A_MINUS, 4);
    courseAlgorithm = new GradeRecord("CS5800", Grade.B, 4);
    course5600 = new GradeRecord("CS5600", Grade.B_PLUS, 4);
    course5500 = new GradeRecord("CS5500", Grade.B_MINUS, 3);
    course5004 = new GradeRecord("CS5004", Grade.B_MINUS, 4);
    course5005 = new GradeRecord("CS5005", Grade.B_MINUS, 4);
    subject5100 = new GradeRecord("CS5100", Grade.A, 4);
  }

  /**
   * Testing for satisfied conditions of all observers.
   */
  @Test
  public void testAllSatisfiedObserver() {
    student.attach(coopObserver);
    student.attach(goodStandingObserver);
    student.attach(graduationEligibleObserver);
    student.notify(coursePdp);
    student.notify(courseDbms);
    student.notify(courseAlgorithm);
    student.notify(course5600);
    student.notify(course5500);
    assertEquals(true, coopObserver.isSatisfied());
    assertEquals(true, goodStandingObserver.isSatisfied());
    assertEquals(true, graduationEligibleObserver.isSatisfied());
  }

  /**
   * Testing for not satisfied condition of coop Observer due to credits.
   */
  @Test
  public void testNotSatisfiedCoopObserverDueToCredits() {
    student.attach(coopObserver);
    student.notify(coursePdp);
    student.notify(courseDbms);
    student.notify(courseAlgorithm);
    assertEquals(false, coopObserver.isSatisfied());
  }

  /**
   * Testing for not satisfied condition of coop Observer due to grade.
   */
  @Test
  public void testNotSatisfiedCoopObserverDueToGrade() {
    student.attach(coopObserver);
    student.notify(course5600);
    student.notify(course5500);
    student.notify(course5004);
    student.notify(course5005);
    assertEquals(false, coopObserver.isSatisfied());
  }

  /**
   * Testing for not satisfied condition of graduation Observer due to grade.
   */
  @Test
  public void testNotSatisfiedGraduationObserverDueToGrade() {
    student.attach(graduationEligibleObserver);
    GradeRecord lowMarksSubjectCS5010 = new GradeRecord("CS5010", Grade.C, 4);
    GradeRecord lowMarksSubjectCS5800 = new GradeRecord("CS580", Grade.C, 4);
    GradeRecord lowMarksSubjectCS5500 = new GradeRecord("CS5500", Grade.B, 4);
    student.notify(lowMarksSubjectCS5010);
    student.notify(lowMarksSubjectCS5800);
    student.notify(lowMarksSubjectCS5500);
    student.notify(courseDbms);
    assertEquals(false, graduationEligibleObserver.isSatisfied());
  }

  /**
   * Testing for not satisfied condition of graduation Observer due to no CS5010
   * or CS5004.
   */
  @Test
  public void testNotSatisfiedGraduationObserverDueToNoCS5010orCS5004() {
    student.attach(graduationEligibleObserver);
    GradeRecord highMarksSubjectCS5800 = new GradeRecord("CS5800", Grade.A, 4);
    GradeRecord highMarksSubjectCS5500 = new GradeRecord("CS5500", Grade.A, 4);
    student.notify(courseDbms);
    student.notify(subject5100);
    student.notify(highMarksSubjectCS5500);
    student.notify(highMarksSubjectCS5800);
    assertEquals(false, graduationEligibleObserver.isSatisfied());
  }

  /**
   * Testing for not satisfied condition of graduation Observer due to no CS5800.
   */
  @Test
  public void testNotSatisfiedGraduationObserverDueToNoCS5800() {
    student.attach(graduationEligibleObserver);
    GradeRecord highMarksSubjectCS5100 = new GradeRecord("CS5100", Grade.A, 4);
    GradeRecord highMarksSubjectCS5500 = new GradeRecord("CS5500", Grade.A, 4);
    student.notify(courseDbms);
    student.notify(subject5100);
    student.notify(highMarksSubjectCS5500);
    student.notify(highMarksSubjectCS5100);
    assertEquals(false, graduationEligibleObserver.isSatisfied());
  }

  /**
   * Testing for not satisfied condition of graduation Observer.
   */
  @Test
  public void testNotSatisfiedGraduationObserverDueToNoCS5500orCS5600() {
    student.attach(graduationEligibleObserver);
    GradeRecord highMarksSubjectCS5100 = new GradeRecord("CS5100", Grade.A, 4);
    GradeRecord highMarksSubjectCS5800 = new GradeRecord("CS5800", Grade.A, 4);
    student.notify(courseDbms);
    student.notify(subject5100);
    student.notify(highMarksSubjectCS5800);
    student.notify(highMarksSubjectCS5100);
    assertEquals(false, graduationEligibleObserver.isSatisfied());
  }

  /**
   * Testing for not satisfied condition of GoodStanding Observer.
   */
  @Test
  public void testNotSatisfiedGoodStandingObserver() {
    student.attach(goodStandingObserver);
    GradeRecord lowMarksSubjectCS5010 = new GradeRecord("CS5010", Grade.C, 4);
    GradeRecord lowMarksSubjectCS5800 = new GradeRecord("CS580", Grade.C, 4);
    GradeRecord lowMarksSubjectCS5500 = new GradeRecord("CS5500", Grade.B, 4);
    student.notify(lowMarksSubjectCS5010);
    student.notify(lowMarksSubjectCS5800);
    student.notify(lowMarksSubjectCS5500);
    student.notify(courseDbms);
    assertEquals(false, goodStandingObserver.isSatisfied());
  }

  /**
   * Testing for satisfied of coop and not satisfied condition of graduation
   * Observer.
   */
  @Test
  public void testSatisfiedCoopandGraduation() {
    student.attach(graduationEligibleObserver);
    student.attach(coopObserver);
    GradeRecord highMarksSubjectCS5800 = new GradeRecord("CS5800", Grade.A, 4);
    student.notify(coursePdp);
    student.notify(subject5100);
    student.notify(highMarksSubjectCS5800);
    student.notify(courseDbms);
    assertEquals(false, graduationEligibleObserver.isSatisfied());
    assertEquals(true, coopObserver.isSatisfied());
  }

  /**
   * Testing for satisfied of good standing and not satisfied condition of
   * graduation Observer.
   */
  @Test
  public void testSatisfiedGoodStandingandGraduation() {
    student.attach(graduationEligibleObserver);
    student.attach(goodStandingObserver);
    GradeRecord highMarksSubjectCS5500 = new GradeRecord("CS5500", Grade.A, 4);
    GradeRecord highMarksSubjectCS5800 = new GradeRecord("CS5800", Grade.A, 4);
    student.notify(courseDbms);
    student.notify(subject5100);
    student.notify(highMarksSubjectCS5800);
    student.notify(highMarksSubjectCS5500);
    assertEquals(false, graduationEligibleObserver.isSatisfied());
    assertEquals(true, goodStandingObserver.isSatisfied());
  }

  /**
   * Testing for two different instances of observers of coop in which both are
   * satistfied.
   *
   */
  @Test
  public void testSatisfieddifferentObserversOfCoopObserver() {
    student.attach(coopObserver);
    GradeObserver coopObserver2 = new CoopEligible();
    student.attach(coopObserver2);
    student.notify(coursePdp);
    student.notify(courseDbms);
    student.notify(courseAlgorithm);
    student.notify(course5600);
    student.notify(course5500);
    assertEquals(true, coopObserver2.isSatisfied());
    assertEquals(true, coopObserver.isSatisfied());
  }

  /**
   * Testing for two different instances of observers of coop in which one is
   * satisfied and one is not.
   *
   */
  @Test
  public void testSatisfiedAndNotSatisfiedCoopObserver() {
    student.attach(coopObserver);
    GradeObserver coopObserver2 = new CoopEligible();
    student.attach(graduationEligibleObserver);
    student.notify(coursePdp);
    student.notify(courseDbms);
    student.notify(courseAlgorithm);
    student.attach(coopObserver2);
    student.notify(course5600);
    student.notify(course5500);
    assertEquals(false, coopObserver2.isSatisfied());
    assertEquals(true, coopObserver.isSatisfied());
  }

  /**
   * Testing for two different instances of observers of coop in which both are
   * not satistfied.
   *
   */
  @Test
  public void testNotSatisfiedCoopObservers() {

    GradeObserver coopObserver2 = new CoopEligible();
    student.attach(graduationEligibleObserver);
    student.notify(coursePdp);
    student.notify(courseDbms);
    student.notify(courseAlgorithm);
    student.attach(coopObserver2);
    student.attach(coopObserver);
    student.notify(course5600);
    student.notify(course5500);
    assertEquals(false, coopObserver2.isSatisfied());
    assertEquals(false, coopObserver.isSatisfied());
  }

  /**
   * Testing for two different instances of observers of good standing in which
   * both are satistfied.
   *
   */
  @Test
  public void testSatisfieddifferentObserversOfGoodStandingObserver() {
    student.attach(goodStandingObserver);
    GradeObserver goodStandingObserver2 = new GoodStanding();
    student.attach(goodStandingObserver2);
    student.notify(coursePdp);
    student.notify(courseDbms);
    student.notify(courseAlgorithm);
    student.notify(course5600);
    student.notify(course5500);
    assertEquals(true, goodStandingObserver2.isSatisfied());
    assertEquals(true, goodStandingObserver.isSatisfied());
  }

  /**
   * Testing for two different instances of observers of good standing in which
   * one is satisfied and one is not.
   *
   */
  @Test
  public void testSatisfiedAndNotSatisfiedGoodStandingObserver() {
    student.attach(goodStandingObserver);
    student.notify(coursePdp);
    student.notify(courseDbms);
    student.notify(courseAlgorithm);
    student.notify(course5600);
    GradeObserver goodStandingObserver2 = new GoodStanding();
    student.attach(goodStandingObserver2);
    student.notify(course5500);
    assertEquals(false, goodStandingObserver2.isSatisfied());
    assertEquals(true, goodStandingObserver.isSatisfied());
  }

  /**
   * Testing for two different instances of observers of good standing in which
   * both are not satisfied.
   *
   */
  @Test
  public void testNotSatisfiedGoodStandingObservers() {
    GradeObserver goodStandingObserver2 = new GoodStanding();
    student.attach(goodStandingObserver2);
    student.attach(goodStandingObserver);
    student.notify(course5500);
    assertEquals(false, goodStandingObserver2.isSatisfied());
    assertEquals(false, goodStandingObserver.isSatisfied());
  }

  /**
   * Testing for two different instances of observers of graduation in which both
   * are satisfied.
   *
   */
  @Test
  public void testSatisfiedGraduationObservers() {
    student.attach(graduationEligibleObserver);
    GradeObserver graduationEligibleObserver2 = new GraduationEligible();
    student.attach(graduationEligibleObserver2);
    student.notify(coursePdp);
    student.notify(courseDbms);
    student.notify(courseAlgorithm);
    student.notify(course5600);
    student.notify(course5500);
    assertEquals(true, graduationEligibleObserver.isSatisfied());
    assertEquals(true, graduationEligibleObserver2.isSatisfied());
  }

  /**
   * Testing for two different instances of observers of graduation in which one
   * is satisfied and one is not.
   *
   */
  @Test
  public void testSatisfiedAndNotSatisfiedGraduationObserver() {
    student.attach(graduationEligibleObserver);

    student.notify(coursePdp);
    student.notify(courseDbms);
    student.notify(courseAlgorithm);
    student.notify(course5600);
    GradeObserver graduationEligibleObserver2 = new GraduationEligible();
    student.attach(graduationEligibleObserver2);
    student.notify(course5500);
    assertEquals(true, graduationEligibleObserver.isSatisfied());
    assertEquals(false, graduationEligibleObserver2.isSatisfied());
  }

  /**
   * Testing for two different instances of observers of graduation in which both
   * are not satistfied.
   *
   */
  @Test
  public void testNotSatisfiedGraduationObservers() {
    student.attach(graduationEligibleObserver);
    GradeObserver graduationEligibleObserver2 = new GraduationEligible();
    student.attach(graduationEligibleObserver2);
    student.notify(course5500);
    assertEquals(false, graduationEligibleObserver.isSatisfied());
    assertEquals(false, graduationEligibleObserver2.isSatisfied());
  }

  /**
   * Testing for align students.
   */
  @Test
  public void testAlign() {
    student.attach(graduationEligibleObserver);
    student.attach(goodStandingObserver);
    GradeRecord highMarksForSubjectCS5004 = new GradeRecord("CS5004", Grade.A, 4);
    GradeRecord highMarksForSubjectCS5800 = new GradeRecord("CS5800", Grade.A, 4);
    GradeRecord highMarksForSubjectCS5500 = new GradeRecord("CS5500", Grade.A, 4);
    GradeRecord highMarksForSubjectCS5200 = new GradeRecord("CS5200", Grade.A, 4);
    student.notify(highMarksForSubjectCS5800);
    student.notify(highMarksForSubjectCS5004);
    student.notify(highMarksForSubjectCS5500);
    student.notify(highMarksForSubjectCS5200);
    assertEquals(true, graduationEligibleObserver.isSatisfied());
    assertEquals(true, goodStandingObserver.isSatisfied());
  }

  /**
   * Testing for non align students.
   */
  @Test
  public void testNonAlign() {
    student.attach(graduationEligibleObserver);
    student.attach(goodStandingObserver);
    GradeRecord highMarksSubjectCS5010 = new GradeRecord("CS5010", Grade.A, 4);
    GradeRecord highMarksSubjectCS5800 = new GradeRecord("CS5800", Grade.A, 4);
    GradeRecord highMarksSubjectCS5500 = new GradeRecord("CS5500", Grade.A, 4);
    GradeRecord highMarksSubjectCS5200 = new GradeRecord("CS5200", Grade.A, 4);
    student.notify(highMarksSubjectCS5800);
    student.notify(highMarksSubjectCS5010);
    student.notify(highMarksSubjectCS5500);
    student.notify(highMarksSubjectCS5200);
    assertEquals(true, graduationEligibleObserver.isSatisfied());
    assertEquals(true, goodStandingObserver.isSatisfied());
  }

  /**
   * Testing for CS5500 students.
   */
  @Test
  public void testCS5500Courses() {
    student.attach(graduationEligibleObserver);
    student.attach(goodStandingObserver);
    GradeRecord highMarksSubjectCS5010 = new GradeRecord("CS5010", Grade.A, 4);
    GradeRecord highMarksSubjectCS5800 = new GradeRecord("CS5800", Grade.A, 4);
    GradeRecord highMarksSubjectCS5500 = new GradeRecord("CS5500", Grade.A, 4);
    GradeRecord highMarksSubjectCS5200 = new GradeRecord("CS5200", Grade.A, 4);
    student.notify(highMarksSubjectCS5800);
    student.notify(highMarksSubjectCS5010);
    student.notify(highMarksSubjectCS5500);
    student.notify(highMarksSubjectCS5200);
    assertEquals(true, graduationEligibleObserver.isSatisfied());
    assertEquals(true, goodStandingObserver.isSatisfied());
  }

  /**
   * Testing for CS5600 students.
   */
  @Test
  public void testCS5600Courses() {
    student.attach(graduationEligibleObserver);
    student.attach(goodStandingObserver);
    GradeRecord highMarksSubjectCS5010 = new GradeRecord("CS5010", Grade.A, 4);
    GradeRecord highMarksSubjectCS5800 = new GradeRecord("CS5800", Grade.A, 4);
    GradeRecord highMarksSubjectCS5600 = new GradeRecord("CS5600", Grade.A, 4);
    GradeRecord highMarksSubjectCS5200 = new GradeRecord("CS5200", Grade.A, 4);
    student.notify(highMarksSubjectCS5800);
    student.notify(highMarksSubjectCS5010);
    student.notify(highMarksSubjectCS5600);
    student.notify(highMarksSubjectCS5200);
    assertEquals(true, graduationEligibleObserver.isSatisfied());
    assertEquals(true, goodStandingObserver.isSatisfied());
  }

  /**
   * Check for min by max repetition of subjects.
   */
  @Test
  public void testUpdatedMinMarksbyMaxMarks() {
    student.attach(graduationEligibleObserver);
    student.attach(goodStandingObserver);
    GradeRecord lowMarksSubjectCS5010 = new GradeRecord("CS5010", Grade.C, 4);
    GradeRecord lowMarksSubjectCS5800 = new GradeRecord("CS5800", Grade.C, 4);
    GradeRecord lowMarksSubjectCS5600 = new GradeRecord("CS5600", Grade.C, 4);
    GradeRecord lowMarksSubjectCS5200 = new GradeRecord("CS5200", Grade.C, 4);
    student.notify(lowMarksSubjectCS5800);
    student.notify(lowMarksSubjectCS5010);
    student.notify(lowMarksSubjectCS5600);
    student.notify(lowMarksSubjectCS5200);
    assertEquals(false, graduationEligibleObserver.isSatisfied());
    assertEquals(false, goodStandingObserver.isSatisfied());
    GradeRecord highMarksSubjectCS5010 = new GradeRecord("CS5010", Grade.A, 4);
    GradeRecord highMarksSubjectCS5800 = new GradeRecord("CS5800", Grade.A, 4);
    GradeRecord highMarksSubjectCS5600 = new GradeRecord("CS5600", Grade.A, 4);
    GradeRecord highMarksSubjectCS5200 = new GradeRecord("CS5200", Grade.A, 4);
    student.notify(highMarksSubjectCS5800);
    student.notify(highMarksSubjectCS5010);
    student.notify(highMarksSubjectCS5600);
    student.notify(highMarksSubjectCS5200);
    assertEquals(true, graduationEligibleObserver.isSatisfied());
    assertEquals(true, goodStandingObserver.isSatisfied());
  }

  /**
   * Check for max by min repetition of subjects.
   */
  @Test
  public void testUpdatedMaxMarksbyMinMarks() {
    student.attach(graduationEligibleObserver);
    student.attach(goodStandingObserver);
    GradeRecord highMarksSubjectCS5010 = new GradeRecord("CS5010", Grade.A, 4);
    GradeRecord highMarksSubjectCS5800 = new GradeRecord("CS5800", Grade.A, 4);
    GradeRecord highMarksSubjectCS5600 = new GradeRecord("CS5600", Grade.A, 4);
    GradeRecord highMarksSubjectCS5200 = new GradeRecord("CS5200", Grade.A, 4);

    student.notify(highMarksSubjectCS5800);
    student.notify(highMarksSubjectCS5010);
    student.notify(highMarksSubjectCS5600);
    student.notify(highMarksSubjectCS5200);
    assertEquals(true, graduationEligibleObserver.isSatisfied());
    assertEquals(true, goodStandingObserver.isSatisfied());
    GradeRecord lowMarksSubjectCS5010 = new GradeRecord("CS5010", Grade.C, 4);
    GradeRecord lowMarksSubjectCS5800 = new GradeRecord("CS5800", Grade.C, 4);
    GradeRecord lowMarksSubjectCS5600 = new GradeRecord("CS5600", Grade.C, 4);
    GradeRecord lowMarksSubjectCS5200 = new GradeRecord("CS5200", Grade.C, 4);
    student.notify(lowMarksSubjectCS5800);
    student.notify(lowMarksSubjectCS5010);
    student.notify(lowMarksSubjectCS5600);
    student.notify(lowMarksSubjectCS5200);
    assertEquals(true, graduationEligibleObserver.isSatisfied());
    assertEquals(true, goodStandingObserver.isSatisfied());
  }

  /**
   * Testing for null for good standing update method.
   */
  @Test(expected = IllegalArgumentException.class)
  public void nullForGoodStandingUpdate() {
    goodStandingObserver.update(null);
  }

  /**
   * Testing for null for graduation eligible update method.
   */
  @Test(expected = IllegalArgumentException.class)
  public void nullForGraduationEligibleUpdate() {
    graduationEligibleObserver.update(null);
  }

  /**
   * Testing for null for Coop update method.
   */
  @Test(expected = IllegalArgumentException.class)
  public void nullForCoopUpdate() {
    coopObserver.update(null);
  }

  /**
   * Testing constructor for coop eligible observer.
   */
  @Test
  public void testConstructorForCoopEligible() {
    assertEquals("Coop Eligible observer:", coopObserver.toString());
  }

  /**
   * Testing constructor for graduation eligible eligible observer.
   */
  @Test
  public void testConstructorForGraduationEligible() {
    assertEquals("Graduation Eligible observer:", graduationEligibleObserver.toString());
  }

  /**
   * Testing constructor for good standing eligible observer.
   */
  @Test
  public void testConstructorForGoodStanding() {
    assertEquals("Good Standing observer:", goodStandingObserver.toString());
  }

  /**
   * Testing directly updating for observer without updating the grade subject for
   * individual methods of coop observer.
   */
  @Test
  public void testupdateCoop() {
    coopObserver.update(coursePdp);
    coopObserver.update(courseDbms);
    coopObserver.update(courseAlgorithm);
    coopObserver.update(course5600);
    assertEquals("Coop Eligible observer:CoursesCS5010,CS5200,CS5800,CS5600",
        coopObserver.toString());
    assertEquals(true, coopObserver.isSatisfied());
  }

  /**
   * Testing directly updating for observer without updating the grade subject for
   * individual methods of Graduation Eligible observer.
   */
  @Test
  public void testupdateGraduation() {
    graduationEligibleObserver.update(coursePdp);
    graduationEligibleObserver.update(courseDbms);
    graduationEligibleObserver.update(courseAlgorithm);
    graduationEligibleObserver.update(course5600);
    assertEquals("Graduation Eligible observer:CoursesCS5010,CS5200,CS5800,CS5600",
        graduationEligibleObserver.toString());
    assertEquals(true, graduationEligibleObserver.isSatisfied());
  }

  /**
   * Testing directly updating for observer without updating the grade subject for
   * individual methods of GoodStanding observer.
   */
  @Test
  public void testupdateGoodStanding() {
    goodStandingObserver.update(coursePdp);
    goodStandingObserver.update(courseDbms);
    goodStandingObserver.update(courseAlgorithm);
    goodStandingObserver.update(course5600);
    assertEquals("Good Standing observer:CoursesCS5010,CS5200,CS5800,CS5600",
        goodStandingObserver.toString());
    assertEquals(true, goodStandingObserver.isSatisfied());
  }
}
